﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Microsoft.Extensions.Configuration;
//using System;
//using System.Collections.Generic;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;



namespace LoanManagementSystemApp.Utility
{
    internal class ConfigurationBuilder
    {
        public ConfigurationBuilder()
        {
        }

        internal object SetBasePath(string v)
        {
            throw new NotImplementedException();
        }
    }
}